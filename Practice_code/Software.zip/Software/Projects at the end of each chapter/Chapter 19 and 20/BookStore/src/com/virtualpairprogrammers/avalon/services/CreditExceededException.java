package com.virtualpairprogrammers.avalon.services;

public class CreditExceededException extends Exception {

}
