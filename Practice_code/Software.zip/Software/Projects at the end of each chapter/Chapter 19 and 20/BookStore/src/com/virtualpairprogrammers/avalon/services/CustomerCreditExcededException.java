package com.virtualpairprogrammers.avalon.services;

public class CustomerCreditExcededException extends Exception {

}
