package com.virtualpairprogrammers.avalon.services;

import com.virtualpairprogrammers.avalon.domain.Book;

public interface AccountsService 
{
	public void raiseInvoice(Book requiredBook) throws CustomerCreditExcededException;
}
