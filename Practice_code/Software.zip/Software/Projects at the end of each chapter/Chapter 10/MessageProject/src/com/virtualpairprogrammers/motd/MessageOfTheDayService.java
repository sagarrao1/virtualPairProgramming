package com.virtualpairprogrammers.motd;

public interface MessageOfTheDayService 
{
	public String getTodaysMessage();
}
