package com.virtualpairprogrammers.dataaccess;

public class RecordNotFoundException extends Exception {

	/**
	 * Just to stop warnings.
	 */
	private static final long serialVersionUID = 1L;

}
