package com.virtualpairprogrammers.avalon.services;

public interface PurchasingService 
{
	public void buyBook(String isbn);
}