package com.virtualpairprogrammers.avalon.data;

public class BookNotFoundException extends Exception {

}
